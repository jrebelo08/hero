package com.arcinard.hero;

import com.googlecode.lanterna.graphics.TextGraphics;

public class Monster extends Element{
    Monster(int x,int y){
        super(x,y);
    }
    @Override
    public void draw(TextGraphics textGraphics) {
        textGraphics.putString(position.getX(), position.getY(), "M");
    }
    public Position moveUp(){
        return new Position(get_X(), get_Y() - 1);
    }
    public Position moveDown(){
        return new Position(get_X(), get_Y() + 1);
    }
    public Position moveRight(){
        return new Position(get_X() + 1, get_Y());
    }
    public Position moveLeft(){
        return new Position(get_X() - 1, get_Y());
    }
    public int get_X() {
        return position.getX();
    }
    public int get_Y() {
        return position.getY();
    }

}
